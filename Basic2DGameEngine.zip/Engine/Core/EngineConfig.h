#pragma once

#include <cstdint>

enum class WindowMode
{
    Windowed,
    BorderlessFullscreen
};

struct EngineConfig
{
    // Window
    int windowWidth = 1280;
    int windowHeight = 720;

    WindowMode windowMode =
        WindowMode::Windowed;

    // Rendering
    bool vsync = false;

    // 0 = Unlimited
    std::uint32_t targetFPS = 144;

    // Fixed Update
    float fixedUpdateHz = 60.0f;

    // �� Render Frame���� ������
    // �ִ� FixedUpdate Ƚ��
    std::uint32_t maxFixedSteps = 5;

    // ����ġ�� ū frame delta ����
    float maxDeltaTime = 0.1f;

    // Window Focus
    bool pauseWhenUnfocused = true;

    // Debug
    bool showDebugCollider = true;
    bool showRuntimeStats = true;
};